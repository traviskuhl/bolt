#!/usr/bin/env php
<?php
///////////////////////////////////////////////////////////////////////
/// (c) the.kuhl.co 2012 - author: travis kuhl (travis@kuhl.co)
///
/// Licensed under the Apache License, Version 2.0 (the "License");
/// you may not use this work except in  compliance with the License.
/// You may obtain a copy of the License in the LICENSE file, or at:
///
/// http://www.apache.org/licenses/LICENSE-2.0
///
/// Unless required by applicable law or agreed to in writing,
/// software distributed under the License is distributed on an "AS IS"
/// BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
/// express or implied. See the License for the specific language
/// governing permissions and limitations under the License.
///////////////////////////////////////////////////////////////////////
/// Build: 3c4c0df / 2013-02-24 19:28:10 -0800
/// Compiled: Mon, 25 Feb 2013 03:28:10 +0000

// include bolt
require("%PHAR%/bolt.php");

// if we're in cli, load it
// otherwise we're just including the phar
if ('cli' === php_sapi_name()) {

    b::init(array(
        'load' => array(
            "$root/bolt/cli.php",
            "$root/bolt/client/*.php"
        )
    ));

    // run in cli mode
    b::run('cli');

}
else {
    exit("Unable to run!");
}